Thank you for downloading from oldgamesdownload.com

If you have any problems playing the game, please first check the tutorials on our wiki page: https://oldgamesdownload.com/wiki/

If you still face any problems, please leave a comment on the page you downloaded the game from.

Happy retrogaming!